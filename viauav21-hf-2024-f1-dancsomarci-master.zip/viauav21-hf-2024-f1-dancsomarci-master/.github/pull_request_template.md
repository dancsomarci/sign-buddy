#### Emlékeztető a _pull request_ használatáról

- A megoldásod a laborvezető fogja pontozni, a házi feladatnál nincs automatikus értékelés.
- A specifikációhoz és a teljes beadáshoz is nyitnod kell egy-egy külön PR-et a *spec* és a *hf* brancheken.
- A laborvezetődhöz akkor rendeld a pull request-et, amikor készen vagy, és beadod a specifikáció vagy megoldást.
- Ne merge-eld a pull request-et.

A folyamatot részletesen lásd itt: <https://viauav21.github.io/laborok/GitHub/>